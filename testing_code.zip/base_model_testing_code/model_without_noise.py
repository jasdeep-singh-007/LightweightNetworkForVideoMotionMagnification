
import tensorflow as tf
import tensorflow.keras
from tensorflow.keras.layers import Dense, Conv2D, Flatten, MaxPool2D, Dropout, Input
import keras
from keras import backend as k
import tensorflow as tf
import tensorflow.keras
from tensorflow.keras.layers import Dense, Conv2D, Flatten, MaxPool2D, Dropout, Input
import keras
from keras import backend as k

filters_=24
image_height=384
image_width=384
activaion_function='elu'
from numba import jit, cuda 

vgg16=tf.keras.applications.VGG16(
    include_top=True, input_tensor=None, input_shape=None,weights='imagenet',
    pooling=None, classes=1000, classifier_activation='softmax')
vgg16.trainable=False
fullModel = tf.keras.models.Model(inputs = vgg16.input, outputs = vgg16.layers[9].output)
fullModel.compile(loss='mse', optimizer='adam')

def mse_loss(y_true, y_pred):
    mse_loss=tf.keras.losses.MAE(y_true, y_pred)
    return  mse_loss*10
def ssim_loss(y_true, y_pred):
    ssim_loss=-tf.image.ssim(y_pred, y_true, 2 )    
    return multiply_variable(ssim_loss)

def Residual_block (input,filters_,kernal):
  out1=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(input)
  out1=tf.keras.layers.Activation(activation=activaion_function)(out1)
  out2=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(out1)
  out2=tf.keras.layers.Add()([out2,input])
  out2=tf.keras.layers.Activation(activation=activaion_function)(out2)
  return out2
kernal=3
frame_A_encoder=tf.keras.Input(shape=(image_height,image_width,3))
frame_B_encoder=tf.keras.Input(shape=(image_height,image_width,3))
magnification_factor_encoder=tf.keras.Input(shape=(1,))
frame_1_out_encoder=tf.keras.layers.concatenate([frame_A_encoder,frame_B_encoder])

frame_1_out_encoder=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(frame_1_out_encoder)
frame_1_out_encoder=tf.keras.layers.Activation(activation=activaion_function)(frame_1_out_encoder)

frame_1_out_encoder=Residual_block(frame_1_out_encoder,filters_,3)
frame_1_out_encoder=Residual_block(frame_1_out_encoder,filters_,3)
frame_1_out_encoder=Residual_block(frame_1_out_encoder,filters_,3)

frame_1_out_2_concatinate_encoder =tf.keras.layers.MaxPool2D(pool_size=(2, 2),padding="valid")(frame_1_out_encoder)
frame_2_out_encoder=tf.keras.layers.concatenate([frame_B_encoder,frame_A_encoder])

frame_2_out_encoder=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(frame_2_out_encoder)
frame_2_out_encoder=tf.keras.layers.Activation(activation=activaion_function)(frame_2_out_encoder)
frame_2_out_encoder=Residual_block(frame_2_out_encoder,filters_,3)
frame_2_out_encoder=Residual_block(frame_2_out_encoder,filters_,3)
frame_2_out_encoder=Residual_block(frame_2_out_encoder,filters_,3)
frame_2_out_2_concatinate_encoder =tf.keras.layers.MaxPool2D(pool_size=(2, 2), padding="valid")(frame_2_out_encoder)

frame_1_out_2_encoder=tf.keras.layers.concatenate([frame_1_out_2_concatinate_encoder,frame_2_out_2_concatinate_encoder])

frame_1_out_2_encoder=tf.keras.layers.Conv2D(filters=filters_*2, kernel_size=(3,3),dilation_rate=1,strides=(1, 1),padding="same")(frame_1_out_2_encoder)

frame_1_out_2_encoder=tf.keras.layers.Activation(activation=activaion_function)(frame_1_out_2_encoder)
frame_1_out_2_encoder=Residual_block(frame_1_out_2_encoder,filters_*2,3)
frame_1_out_2_encoder=Residual_block(frame_1_out_2_encoder,filters_*2,3)
frame_1_out_2_encoder=Residual_block(frame_1_out_2_encoder,filters_*2,3)
frame_1_out_3_concatinate_encoder =tf.keras.layers.MaxPool2D(pool_size=(2, 2),padding="valid")(frame_1_out_2_concatinate_encoder)

frame_2_out_2_encoder=tf.keras.layers.concatenate([frame_2_out_2_concatinate_encoder,frame_1_out_2_concatinate_encoder])

frame_2_out_2_encoder=tf.keras.layers.Conv2D(filters=filters_*2, kernel_size=(kernal,kernal),dilation_rate=1,strides=(1, 1),padding="same")(frame_2_out_2_encoder)
frame_2_out_2_encoder=tf.keras.layers.Activation(activation=activaion_function)(frame_2_out_2_encoder)
frame_2_out_2_encoder=Residual_block(frame_2_out_2_encoder,filters_*2,3)
frame_2_out_2_encoder=Residual_block(frame_2_out_2_encoder,filters_*2,3)
frame_2_out_2_encoder=Residual_block(frame_2_out_2_encoder,filters_*2,3)

frame_2_out_3_1_encoder=tf.keras.layers.concatenate([ frame_1_out_2_concatinate_encoder,frame_2_out_2_concatinate_encoder])

frame_2_out_3_1_encoder=tf.keras.layers.Conv2D(filters=filters_*2, kernel_size=(kernal,kernal),dilation_rate=1,strides=(1, 1),padding="same")(frame_2_out_3_1_encoder)
frame_2_out_3_1_encoder=tf.keras.layers.Activation(activation=activaion_function)(frame_2_out_3_1_encoder)
frame_2_out_3_1_encoder=Residual_block(frame_2_out_3_1_encoder,filters_*2,3)
frame_2_out_3_1_encoder=Residual_block(frame_2_out_3_1_encoder,filters_*2,3)
frame_2_out_3_1_encoder=Residual_block(frame_2_out_3_1_encoder,filters_*2,3)


motion_magnification_encoder_without_noise = tf.keras.Model(inputs=[frame_A_encoder,frame_B_encoder,magnification_factor_encoder],
                outputs=[frame_1_out_2_encoder,frame_2_out_2_encoder,frame_2_out_3_1_encoder,
                magnification_factor_encoder,frame_2_out_2_encoder,frame_2_out_encoder
                ])

#sgd = tf.keras.optimizers.SGD(lr=0.001, decay=1e-6, momentum=0.9, nesterov=True)
adam=tf.keras.optimizers.Adam(
    learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=False,
    name='Adam')

motion_magnification_encoder_without_noise.compile(loss=['mean_absolute_error','mean_absolute_error','mean_absolute_error','mean_absolute_error',
                                   'mean_absolute_error',
                                   'mean_absolute_error'],
                             optimizer=adam, metrics=['accuracy'])
print("correct model file")
frame_1_out_2_subtract=tf.keras.Input(shape=(int(image_height/2), int(image_height/2), filters_*2))
frame_2_out_2_subtract=tf.keras.Input(shape=(int(image_height/2), int(image_height/2), filters_*2))
frame_2_out_3_1_subtract=tf.keras.Input(shape=(int(image_height/2), int(image_height/2), filters_*2))
magnification_factor_subtract=tf.keras.Input(shape=(1,))
frame_2_out_2_2_subtract=tf.keras.Input(shape=(int(image_height/2), int(image_height/2), filters_*2))
frame_2_out_subtract=tf.keras.Input(shape=(int(image_height), int(image_height), filters_))



subtract_two_inputs_subtract=tf.keras.layers.subtract([frame_2_out_2_subtract,frame_1_out_2_subtract])

subtract_two_inputs_subtract=tf.keras.layers.Multiply()([subtract_two_inputs_subtract,magnification_factor_subtract])

motion_magnification_subtract_without_noise = tf.keras.Model(inputs=[frame_1_out_2_subtract,frame_2_out_2_subtract,frame_2_out_3_1_subtract,
	magnification_factor_subtract,frame_2_out_2_2_subtract,frame_2_out_subtract],
                outputs=[subtract_two_inputs_subtract,frame_2_out_3_1_subtract,frame_2_out_2_2_subtract,frame_2_out_subtract
                ])

adam=tf.keras.optimizers.Adam(
    learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=False,
    name='Adam')

motion_magnification_subtract_without_noise.compile(loss=['mean_absolute_error','mean_absolute_error'
                                   'mean_absolute_error','mean_absolute_error'
                                   ],
                             optimizer=adam, metrics=['accuracy'])


subtract_two_inputs_decoder=tf.keras.Input(shape=(int(image_height/2), int(image_height/2), filters_*2))
frame_2_out_3_1_decoder_1=tf.keras.Input(shape=(int(image_height/2), int(image_height/2), filters_*2))

frame_2_out_2_decoder=tf.keras.Input(shape=(int(image_height/2), int(image_height/2), filters_*2))
frame_2_out_decoder=tf.keras.Input(shape=(int(image_height), int(image_height), filters_))
frame_2_out_3_1_decoder =frame_2_out_3_1_decoder_1
frame_2_out_3_1_loss=tf.keras.layers.Conv2D(filters=3, kernel_size=(1,1),strides=(1, 1),padding="same")(frame_2_out_3_1_decoder)
frame_2_out_3_1_loss=tf.keras.layers.Activation(activation='tanh',name='frame_2_out_3_1_loss')(frame_2_out_3_1_loss)
subtract_two_inputs=Residual_block(subtract_two_inputs_decoder,filters_*2,3)
subtract_two_inputs=Residual_block(subtract_two_inputs,filters_*2,3)
subtract_two_inputs=Residual_block(subtract_two_inputs,filters_*2,3)
subtract_two_inputs=Residual_block(subtract_two_inputs,filters_*2,3)


frame_3_out_2=tf.keras.layers.Add()([subtract_two_inputs,frame_2_out_3_1_decoder])

frame_3_out_2=tf.keras.layers.Conv2D(filters=filters_*2, kernel_size=(kernal,kernal),strides=(1, 1),padding="same")(frame_3_out_2)

frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)
frame_3_out_2=Residual_block(frame_3_out_2,filters_*2,3)

frame_3_out_2_loss=tf.keras.layers.Conv2D(filters=3, kernel_size=(1,1),strides=(1, 1),padding="same")(frame_3_out_2)
frame_3_out_2_loss=tf.keras.layers.Activation(activation='tanh',name='frame_3_out_2_loss')(frame_3_out_2_loss)

frame_3_out_1 =tf.keras.layers.Conv2DTranspose(filters=(filters_), kernel_size=(2,2),strides=(2, 2),padding="same")(frame_3_out_2)
frame_3_out_1=tf.keras.layers.Activation(activation=activaion_function)(frame_3_out_1)

frame_3_out_1=tf.keras.layers.Conv2D(filters=filters_, kernel_size=(kernal,kernal),strides=(1, 1),padding="same")(frame_3_out_1)

frame_3_out_1=Residual_block(frame_3_out_1,filters_,3)
frame_3_out_1=Residual_block(frame_3_out_1,filters_,3)
frame_3_out_1=Residual_block(frame_3_out_1,filters_,3)

frame_3_out_1=tf.keras.layers.Conv2D(filters=3, kernel_size=(1,1),strides=(1, 1),padding="same")(frame_3_out_1)
frame_3_out_1=tf.keras.layers.Activation(activation='tanh',name='frame_3_out_1')(frame_3_out_1)


motion_magnification_decoder_without_noise = tf.keras.Model(inputs=[subtract_two_inputs_decoder,
                frame_2_out_3_1_decoder_1,frame_2_out_2_decoder,frame_2_out_decoder],
                outputs=[frame_3_out_1,frame_3_out_2_loss,frame_2_out_3_1_loss])

adam=tf.keras.optimizers.Adam(
    learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=False,
    name='Adam')

motion_magnification_decoder_without_noise.compile(loss=['mean_absolute_error','mean_absolute_error'
                                   ,'mean_absolute_error'
                                   ],
                             optimizer=adam, metrics=['accuracy'])


frame_A=tf.keras.Input(shape=(image_height,image_width,3))
frame_B=tf.keras.Input(shape=(image_height,image_width,3))
magnification_factor=tf.keras.Input(shape=(1,))

frame_1_out_3_2,frame_2_out_3_2,frame_2_out_3_1_2,magnification_factor_2,frame_2_out_2_2,frame_2_out_1_2=motion_magnification_encoder_without_noise(
	[frame_A,frame_B,magnification_factor])

subtract_two_inputs_3,frame_2_out_3_1_3,frame_2_out_2_3,frame_2_out_3=motion_magnification_subtract_without_noise([frame_1_out_3_2,frame_2_out_3_2,frame_2_out_3_1_2,magnification_factor_2,frame_2_out_2_2,frame_2_out_1_2])

frame_3_out_1_4,frame_3_out_2_loss_4,frame_2_out_3_1_loss_4=motion_magnification_decoder_without_noise([subtract_two_inputs_3,frame_2_out_3_1_3,frame_2_out_2_3,frame_2_out_3])


motion_magnification_without_noise = tf.keras.Model(inputs=[frame_A,frame_B,magnification_factor],
                outputs=[frame_3_out_1_4,frame_3_out_1_4,frame_3_out_1_4,frame_3_out_2_loss_4,frame_3_out_2_loss_4,frame_3_out_2_loss_4,
                frame_2_out_3_1_loss_4,frame_2_out_3_1_loss_4
                ])

adam=tf.keras.optimizers.Adam(learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=False,name='Adam')

motion_magnification_without_noise.compile(loss=['mean_absolute_error','mean_absolute_error','mean_absolute_error','mean_absolute_error','mean_absolute_error','mean_absolute_error',
                                   
                                   'mean_absolute_error','mean_absolute_error'
                                   ],
                             optimizer=adam, metrics=['accuracy'])
